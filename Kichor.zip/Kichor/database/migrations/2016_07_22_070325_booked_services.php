<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class BookedServices extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('booked_services', function (Blueprint $table) {
            $table->increments('id');
            $table->string('user_id')->index();
            $table->string('email')->index();
            $table->string('address')->index();
            $table->string('city')->index();
            $table->string('Phone_number')->index();
            $table->string('time')->index();
            $table->string('date')->index();
            $table->string('category')->index();
            $table->string('task_description')->index();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('booked_services');
    }
}
