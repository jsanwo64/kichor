<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::auth();

Route::get('/home', 'HomeController@index');


Route::get('/book_service', 'BookingController@index');


Route::get('/edit', 'UserController@edit');



Route::get('/my_bookings', 'UserController@bookings');

Route::post('book_service', array('uses'=>'BookingController@submit'));


Route::post('/edit', array('uses'=>'UserController@doEdit'));

Route::get('auth/github', 'Auth\AuthController@redirectToProvider');
Route::get('auth/github/callback', 'Auth\AuthController@handleProviderCallback');