<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;
use App\Bookings;
use Auth;
use App\Http\Controllers\Controller;
use Validator;

class BookingController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('book_service');
    }
    
      public function submit(Request $request)
    {
         $validator = Validator::make($request->all(), [
            'city' => 'required',
            'time' => 'required',
            'date' => 'required',
            'category' => 'required',
            'task_description' => 'required',
        ]);

        if ($validator->fails()) {
            return redirect('book_service')
                        ->withErrors($validator)
                        ->withInput();
        }
        
        $id = Auth::user()->id;
        $flight = new Bookings;
        $number = Auth::user()->phone_number;
        
        
        $flight->user_id = $id;
        $flight->email = $request->email;
        $flight->address = $request->address;
        $flight->city = $request->city;
        $flight->Phone_number = $request->Phone_number;
        $flight->time = $request->time;
        $flight->date = $request->date;
        $flight->category = $request->category;
        $flight->task_description = $request->task_description;

        $flight->save();
        
        return redirect('my_bookings')
      ->with('message', 'Your Booking has been received we will contact you shortly!!!'); 
    }
    
}
