<?php

namespace App\Http\Controllers;

use Input;
use Validator;
use DB;
use Hash;
use Auth;
use Redirect;
use Illuminate\Http\Request;

use App\Http\Requests;

class UserController extends Controller
{
    public function edit()
    {
        return view('edit');
        
        
    }
    
    
    
     public function bookings()
    {
          $username = Auth::user()->id;
        $name = DB::table('booked_services')->where('user_id', $username)->get();
         return view('my_bookings', compact('name'));
        
    }
    
    
    
    public function doEdit(Request $request)
  		    {
                  $rules = array(
		'name'             => 'required', 						// just a normal required validation
		'email'            => 'required|email', 	// required and must be unique in the ducks table
		'address'         => 'required', 	// required and must be unique in the ducks table
		'gender'         => 'required', 	// required and must be unique in the ducks table
		'phone_number'         => 'required', 	// required and must be unique in the ducks table
		'password'         => 'required'		// required and has to match the password field
	);

	// do the validation ----------------------------------
	// validate against the inputs from our form
	$validator = Validator::make(Input::all(), $rules);

	// check if the validator failed -----------------------
	if ($validator->fails()) {

		// get the error messages from the validator
		$messages = $validator->messages();

		// redirect our user back to the form with the errors from the validator
		return Redirect::to('/edit')
			->withErrors($validator);

	} else {
  		    	$id = Auth::user()->id;
        	$structure = [
			'name'  => $request->input('name'),
		    'email'  => $request->input('email'),
		    'address'  => $request->input('address'),
		    'gender'  => $request->input('gender'),
		    'phone_number'  => $request->input('phone_number'),
		    'password'  => Hash::make($request->input('password')),
				];

				DB::table('users')->where('id', $id)->update($structure);
return Redirect::to('/home')
        ->withMessage('Profile Updated Successfully!!!');
		 
			}
              }
       
}
