<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta charset="utf-8">
		<title>Bootstrap 3 Control Panel</title>
		<meta name="generator" content="Bootply" />
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<!--[if lt IE 9]>
			<script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
		<link href="css/styles.css" rel="stylesheet">
	</head>
	<body>
<!-- Header -->
<div id="top-nav" class="navbar navbar-inverse navbar-static-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
          <span class="icon-toggle"></span>
      </button>
      <a class="navbar-brand" href="#"><img src="/logo.png"|width="210px" height="50px" style="margin-top: -12px"></a>
    </div>
    <div class="navbar-collapse collapse">
      <ul class="nav navbar-nav navbar-right">
        
        <li class="dropdown">
          <a class="dropdown-toggle" role="button" data-toggle="dropdown" href="#">
            <i class="glyphicon glyphicon-user"></i> Admin <span class="caret"></span></a>
          <ul id="g-account-menu" class="dropdown-menu" role="menu">
            <li><a href="#">My Profile</a></li>
            <li><a href="#"><i class="glyphicon glyphicon-lock"></i> Logout</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div><!-- /container -->
</div>
<!-- /Header -->

<!-- Main -->
<div class="container">
  
  <!-- upper section -->
  <div class="row">
	<div class="col-sm-3">
      <!-- left -->
      <h3 style="color: purple"><i class="glyphicon glyphicon-briefcase"></i> Hello {{ 
      Auth::user()->name
       }}</h3>
      <hr>
      
      <ul class="nav nav-stacked">
        <li><a href="edit" target="ext"><i class="glyphicon glyphicon-flash"></i> Edit My Account </a></li>
        <li><a href="my_bookings" target="ext"><i class="glyphicon glyphicon-link"></i> My Bookings</a></li>
      </ul>
      
      <hr>
      
  	</div><!-- /span-3 -->
      <div class="col-sm-9">
      	
      <!-- column 2 -->	
        <h3 style="color: purple;"><i class="glyphicon glyphicon-dashboard"></i> <b>My Bookings</b></h3>  
            
            <h4 style="text-align">   @if(Session::has('message'))
                                      {{Session::get('message')}}
                                     @endif
                                     </h4>
       <hr>
       
       
       <table class="table table-bordered" style="text-align: center">
   <tr>
       
    <th style="text-align: center">email</th> 
    <th style="text-align: center">Address</th> 
    <th style="text-align: center">City</th> 
    <th style="text-align: center">Time</th> 
    <th style="text-align: center">Date</th> 
    <th style="text-align: center">Task Description</th> 
    <th style="text-align: center">Phone Number</th> 
    <th style="text-align: center">Category</th> 
  </tr>
  @foreach($name as $new)
  <tr>
        <td>{{ $new->email }}</td>
    <td>{{ $new->address }}</td>
    <td>{{ $new->city }}</td>
    <td>{{ $new->time }}</td>
    <td>{{ $new->date }}</td>
    <td>{{ $new->task_description }}</td>
    <td>{{ $new->Phone_number }}</td>
    <td>{{ $new->category }}</td>
  </tr>
  
       @endforeach
</table>
       