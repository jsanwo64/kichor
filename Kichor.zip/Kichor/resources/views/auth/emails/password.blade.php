To initiate the password reset process for your Kichor Account Click here to reset your password: <a href="{{ $link = url('password/reset', $token).'?email='.urlencode($user->getEmailForPasswordReset()) }}"> {{ $link }} </a>
<br>If clicking the link above doesn't work, please copy and paste the URL in a
new browser window instead.If you've received this mail in error, it's likely that another user entered
your email address by mistake while trying to reset a password. If you didn't
initiate the request, you don't need to take any further action and can safely
disregard this email.<br>
Note: This email address cannot accept replies. To fix an issue or learn more
about your account, mail us services@kichor.com<br>
Sincerely,
The Kichor Team
