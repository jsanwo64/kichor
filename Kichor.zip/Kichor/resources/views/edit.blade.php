<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta charset="utf-8">
		<title>Kichor.com | Edit Profile</title>
		<meta name="generator" content="Bootply" />
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<!--[if lt IE 9]>
			<script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
		<link href="css/styles.css" rel="stylesheet">
	</head>
	<body>
<!-- Header -->
<div id="top-nav" class="navbar navbar-inverse navbar-static-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
          <span class="icon-toggle"></span>
      </button>
      <a class="navbar-brand" href="/"><img src="/logo.png"|width="210px" height="50px" style="margin-top: -12px"></a>
    </div>
    <div class="navbar-collapse collapse">
      <ul class="nav navbar-nav navbar-right">
        
        <li class="dropdown">
          <a class="dropdown-toggle" role="button" data-toggle="dropdown" href="#">
            <i class="glyphicon glyphicon-user"></i> 
            {{
            
            Auth::user()->name
            
            }}
             <span class="caret"></span></a>
          <ul id="g-account-menu" class="dropdown-menu" role="menu">
            <li><a href="#">My Profile</a></li>
            <li><a href="#"><i class="glyphicon glyphicon-lock"></i> Logout</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div><!-- /container -->
</div>
<!-- /Header -->

<!-- Main -->
<div class="container">
  
  <!-- upper section -->
  <div class="row">
	<div class="col-sm-3">
      <!-- left -->
      <h3><i class="glyphicon glyphicon-briefcase"></i> Hello {{ 
      Auth::user()->name
       }}</h3>
      <hr>
      
      <ul class="nav nav-stacked">
        <li><a href="edit" target="ext"><i class="glyphicon glyphicon-flash"></i> Account Edit</a></li>
        <li><a href="my_bookings" target="ext"><i class="glyphicon glyphicon-link"></i> My Bookings</a></li>
      </ul>
      
      <hr>
      
  	</div><!-- /span-3 -->
      <div class="col-sm-9">
      	
      <!-- column 2 -->	
       <h3><i class="glyphicon glyphicon-dashboard"></i> Edit your Profile</h3>  
            
       <hr>
       <form class="form-horizontal" method="POST" action="{{ url('/edit') }}">
        {{ csrf_field() }}
           <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Name</label>
    <div class="col-sm-10" @if ($errors->has('name')) has-error @endif">
         @if ($errors->has('name')) <p class="help-block">{{ $errors->first('name') }}</p> @endif
      <input type="text" name="name" class="form-control" id="inputEmail3" placeholder="Name">
    </div>
  </div>
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Email</label>
    <div class="col-sm-10" @if ($errors->has('email')) has-error @endif">
         @if ($errors->has('email')) <p class="help-block">{{ $errors->first('email') }}</p> @endif
      <input type="email"  name="email" class="form-control" id="inputEmail3" placeholder="Email">
    </div>
  </div>
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Address</label>
    <div class="col-sm-10" @if ($errors->has('address')) has-error @endif">
         @if ($errors->has('address')) <p class="help-block">{{ $errors->first('address') }}</p> @endif
      <input type="address" name="address" class="form-control" id="inputEmail3" placeholder="Address">
    </div>
  </div>
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Gender</label>
    <div class="col-sm-10">
      <select class="form-control" name="gender">
  <option value="Male">Male</option>
  <option value="Female">Female</option>
</select>
    </div>
  </div><div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Phone Number</label>
    <div class="col-sm-10" @if ($errors->has('phone_number')) has-error @endif">
         @if ($errors->has('phone_number')) <p class="help-block">{{ $errors->first('phone_number') }}</p> @endif
      <input type="number" name="phone_number" class="form-control" id="inputEmail3" placeholder="Phone Number">
    </div>
  </div>
  <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Password</label>
    <div class="col-sm-10" @if ($errors->has('password')) has-error @endif">
         @if ($errors->has('password')) <p class="help-block">{{ $errors->first('password') }}</p> @endif
      <input type="password" name="password" class="form-control" id="inputPassword3" placeholder="Password">
    </div>
  </div>
 
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-default">Update</button>
    </div>
  </div>
</form>