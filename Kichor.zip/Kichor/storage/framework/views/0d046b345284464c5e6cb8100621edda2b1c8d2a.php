<?php $__env->startSection('content'); ?>
 <header>
        <div class="header-content">
            <div class="header-content-inner">
                <h1 id="homeHeading">YOUR BEST BET FOR GREAT SERVICES</h1>
                <hr>
                <p>It takes only a couple of minutes to get our artisans out to fix that glitch or provide the needed maintenance. We guarantee you best services at best value for your money.</p>
                <a href="#about" class="btn btn-primary btn-xl page-scroll">Masonry</a>
                 <a href="#about" class="btn btn-primary btn-xl page-scroll">Carpentry</a>
                  <a href="#about" class="btn btn-primary btn-xl page-scroll">Home Moving</a>
                   <a href="#about" class="btn btn-primary btn-xl page-scroll">Fumigation</a>
                    <a href="#about" class="btn btn-primary btn-xl page-scroll">Plumbing</a>
            </div>
        </div>
    </header>

    <section class="bg-primary" id="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2 text-center">
                    <h2 class="section-heading"><b>Welcome to KICHOR.com</b></h2>
                    <hr class="light">
                    <p class="text-faded" style="color: white">KICHOR.com is Nigeria's best online total service and maintenance company committed to delivering professional and quality artisan services you can trust to your homes and corporate organisations.
We are the easier, more convenient and smarter way to get your maintenance or services sorted.
</p>
                    <a href="#contact" class="page-scroll btn btn-default btn-xl sr-button">Know more!</a>
                </div>
            </div>
        </div>
    </section>

    <section id="services">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">How it works</h2>
                    <hr class="primary">
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 text-center">
                    <div class="service-box">
                        <i class="fa fa-4x fa-download text-primary sr-icons"></i>
                        <h3>Download the app or visit kichor.com</h3>
                        <p class="text-muted">Select  the service or task you want to get done.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 text-center">
                    <div class="service-box">
                        <i class="fa fa-4x fa-mobile text-primary sr-icons"></i>
                        <h3> We contact you</h3>
                        <p class="text-muted"> We will send you a trusted and verified KICHOR artisan to your evaluate your task.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 text-center">
                    <div class="service-box">
                        <i class="fa fa-4x fa-money text-primary sr-icons"></i>
                        <h3>Pay and Relax</h3>
                        <p class="text-muted">We arrange the details of the job, pay and our artisans get the job done while you do something else</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 text-center">
                    <div class="service-box">
                        <i class="fa fa-4x fa-heart text-primary sr-icons"></i>
                        <h3>Love us More</h3>
                        <p class="text-muted">Tell your friends about Kichor and fall in love with your home over again. </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="no-padding" id="portfolio">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Services</h2>
                    <hr class="primary">
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row no-gutter" style="margin-right: 10px;
    margin-left: 10px; background-color: purple;">
                <div class="col-lg-4 col-sm-6">
                    <a href="book_service" class="portfolio-box">
                        <img src="img/portfolio/thumbnails/mas2.jpg" class="img-responsive" alt="" >
                        <div class="portfolio-box-caption">
                            <div class="portfolio-box-caption-content">
                                <div class="project-category text-faded">
                                    <!--Category-->
                                </div>
                                <div class="project-name">
                                   <h2>Masonry/Tiling</h2>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                
                
                <div class="col-lg-4 col-sm-6">
                    <a href="book_service" class="portfolio-box">
                        <img src="img/pbl.jpeg" class="img-responsive" alt="">
                        <div class="portfolio-box-caption">
                            <div class="portfolio-box-caption-content">
                                <div class="project-category text-faded">
                                    <!--Category-->
                                </div>
                                <div class="project-name">
                                    <h2>Plumbing Works</h2>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <a href="book_service" class="portfolio-box">
                        <img src="img/cap.jpg" class="img-responsive" alt="">
                        <div class="portfolio-box-caption">
                            <div class="portfolio-box-caption-content">
                                <div class="project-category text-faded">
                                    <!--Category-->
                                </div>
                                <div class="project-name">
                            <h2>Carpentry/Upholstery</h2>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <a href="book_service" class="portfolio-box">
                        <img src="img/elec.jpg" class="img-responsive" alt="">
                        <div class="portfolio-box-caption">
                            <div class="portfolio-box-caption-content">
                                <div class="project-category text-faded">
                                    <!--Category-->
                                </div>
                                <div class="project-name">
                                    <h2>Electrical Works</h2>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <a href="book_service" class="portfolio-box">
                        <img src="img/portfolio/thumbnails/fum.jpg" class="img-responsive" alt="">
                        <div class="portfolio-box-caption">
                            <div class="portfolio-box-caption-content">
                                <div class="project-category text-faded">
                                   <!--Category-->
                                </div>
                                <div class="project-name">
                                    <h2>Fumigation/Pest Control</h2>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <a href="book_service" class="portfolio-box">
                        <img src="img/paint.jpg" class="img-responsive" alt="">
                        <div class="portfolio-box-caption">
                            <div class="portfolio-box-caption-content">
                                <div class="project-category text-faded">
                                    <!--Category-->
                                </div>
                                <div class="project-name">
                                    <h2>Painting</h2>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </section>

    <aside class="bg-dark">
        <div class="container text-center">
            <div class="call-to-action">
                <h2><b>Get the <img src="/logo.png"|width="210px" height="50px"> APP</b></h2>
                <a href="#" class="btn btn-default btn-xl sr-button"> <i class="fa fa-android fa-3x" aria-hidden="true"></i>  Android<br>Download</a>&nbsp&nbsp <a href="#" class="btn btn-default btn-xl sr-button"> <i class="fa fa-apple fa-3x" aria-hidden="true"></i>  IOS<br>Download</a>
            </div>
        </div>
    </aside>

    <section id="contact">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2 text-center">
                    <h2 class="section-heading">Contact Us!</h2>
                    <hr class="primary">
                    <p>Get in touch with us today </p></div>
                <div class="col-lg-4 col-lg-offset-2 text-center">
                    <i class="fa fa-phone fa-3x sr-contact" style="color: purple;"></i>
                    <p>+234(0)8099414496</p>
                </div>
                <div class="col-lg-4 text-center">
                    <i class="fa fa-envelope-o fa-3x sr-contact" style="color: purple;"></i>
                    <p><a href="mailto:services@kichor.com" style="color: black;">services@kichor.com</a></p>
                </div><br>
                 <div class="col-lg-4 col-lg-offset-2 text-center">
                    <a href="" ><i class="fa fa-twitter fa-4x" aria-hidden="true"></i></a>
                    <p>Twitter</p>
                </div>
                <div class="col-lg-4 text-center">
                    <a href="http://www.instagram.com/Kichorng"><i class="fa fa-instagram fa-4x" aria-hidden="true"></i></a>
                     <p>Instagram</p>
                    <p> 
                </div>
            </div>
        </div>
    </section>

    <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <script src="vendor/scrollreveal/scrollreveal.min.js"></script>
    <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

    <!-- Theme JavaScript -->
    <script src="js/creative.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>