<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta charset="utf-8">
		<title>Kichor.com | Profile</title>
		<meta name="generator" content="Bootply" />
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<!--[if lt IE 9]>
			<script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
		<link href="css/styles.css" rel="stylesheet">
	</head>
	<body>
<!-- Header -->
<div id="top-nav" class="navbar navbar-inverse navbar-static-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
          <span class="icon-toggle"></span>
      </button>
      <a class="navbar-brand" href="/"><img src="/logo.png"|width="210px" height="50px" style="margin-top: -12px"></a>
    </div>
    <div class="navbar-collapse collapse">
      <ul class="nav navbar-nav navbar-right">
        
        <li class="dropdown">
          <a class="dropdown-toggle" role="button" data-toggle="dropdown" href="#">
            <i class="glyphicon glyphicon-user"></i> 
             <?php echo e(Auth::user()->name); ?> <span class="caret"></span></a>
          <ul id="g-account-menu" class="dropdown-menu" role="menu">
            <li><a href="#">My Profile</a></li>
            <li><a href="#"><i class="glyphicon glyphicon-lock"></i> Logout</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div><!-- /container -->
</div>
<!-- /Header -->

<!-- Main -->
<div class="container">
  
  <!-- upper section -->
  <div class="row">
	<div class="col-sm-3">
      <!-- left -->
      <h3><i class="glyphicon glyphicon-briefcase"></i> Hello <?php echo e(Auth::user()->name); ?></h3>
      <hr>
      
      <ul class="nav nav-stacked">
        <li><a href="edit" target="ext"><i class="glyphicon glyphicon-flash"></i> Account Edit</a></li>
        <li><a href="my_bookings" target="ext"><i class="glyphicon glyphicon-link"></i> My Bookings</a></li>
      </ul>
      
      <hr>
      
  	</div><!-- /span-3 -->
    <div class="col-sm-9">
      	
      <!-- column 2 -->	
       <h3><i class="glyphicon glyphicon-dashboard"></i> Welcome to your Kichor Profile</h3>  
            
            <br>
            <h5><b>Note: You will have to complete your profile before you can start booking services, <a href="/edit">click here</a>
             to complete your profile</b></h5>
            <h4 style="text-align">   <?php if(Session::has('message')): ?>
                                      <?php echo e(Session::get('message')); ?>

                                     <?php endif; ?>
                                     </h3>
       <hr>
      
	  <table class="table table-bordered" style="text-align: center">
   <tr>
    <th style="text-align: center">Full Name </th>
    <th style="text-align: center">Email</th> 
    <th style="text-align: center">Address </th>
    <th style="text-align: center">Phone Number</th> 
  </tr>
  <tr>
    <td><?php echo e(Auth::user()->name); ?></td>
    <td><?php echo e(Auth::user()->email); ?></td> 
       <td><?php echo e(Auth::user()->address); ?></td> 
       <td><?php echo e(Auth::user()->phone_number); ?></td> 
  </tr>
</table>


  </div>
	<!-- script references -->
		<script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	</body>
</html>