<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>

    <!-- Plugin CSS -->
    <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet">

    <!-- Theme CSS -->
    <link href="css/creative.min.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->


 
</head>
<body id="page-top">
    <div id="top-nav" class="navbar navbar-inverse navbar-static-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
          <span class="icon-toggle"></span>
      </button>
      <a class="navbar-brand" href="#">Welcome <?php echo e(Auth::user()->name); ?></a>
    </div>
    <div class="navbar-collapse collapse">
      <ul class="nav navbar-nav navbar-right">
        
        <li class="dropdown">
          <a class="dropdown-toggle" role="button" data-toggle="dropdown" href="#">
            <i class="glyphicon glyphicon-user"></i> 
             <?php echo e(Auth::user()->name); ?>

             <span class="caret"></span></a>
          <ul id="g-account-menu" class="dropdown-menu" role="menu">
            <li><a href="#">My Profile</a></li>
            <li><a href="#"><i class="glyphicon glyphicon-lock"></i> Logout</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div><!-- /container -->
</div>
<!-- /Header -->
    
    
    <div class="container">
    <br><br><br><br>
    <h3><center><b> Fill the form below to book a service</b></center></h3>
   
      <form role="form" method="POST" action="<?php echo e(url('/book_service')); ?>">
           <?php echo e(csrf_field()); ?>

 		<div class="form-group">
    		<label for="inputEmail3" class="col-sm-2 control-label">Name</label>
    		<div class="col-sm-10">
      		<input type="text" class="form-control" id="inputEmail3" value="<?php echo e(Auth::user()->name); ?>" name="name" readonly>
    	</div>     <br><br><br>
 		<div class="form-group">
    		<label for="inputEmail3" class="col-sm-2 control-label">Email</label>
    		<div class="col-sm-10">
      		<input type="email" class="form-control" id="inputEmail3" placeholder="Email" name="email" value="<?php echo e(Auth::user()->email); ?>"  readonly>
    	</div>    
        <br><br><br><div class="form-group">
    		<label for="inputEmail3" class="col-sm-2 control-label">Address</label>
    		<div class="col-sm-10">
      		<input type="text" class="form-control" id="inputEmail3" placeholder="Address" name="address" value="<?php echo e(Auth::user()->address); ?>" readonly>
    	</div> 
         <br><br><br><div class="form-group">
    		<label for="inputEmail3" class="col-sm-2 control-label">City</label>
    		<div class="col-sm-10">
          <select class="form-control" name="city">
<option value="Agege">Agege</option>
<option value="Ajeromi-Ifelodun">Ajeromi-Ifelodun</option>
<option value="Alimosho">Alimosho</option>
<option value="Amuwo-Odofin">Amuwo-Odofin</option>
<option value="Apapa">Apapa</option>
<option value="Badagry">Badagry</option>
<option value="Epe">Epe</option>
<option value="AgEti Osaege">Eti Osa</option>
<option value="Ibeju-Lekki">Ibeju-Lekki</option>
<option value="Ifako-Ijaiye">Ifako-Ijaiye</option>
<option value="Ikeja">Ikeja</option>
<option value="Ikorodu">Ikorodu</option>
<option value="Kosofe">Kosofe</option>
<option value="Lagos Island">Lagos Island</option>
<option value="Lagos Mainland">Lagos Mainland (Ebute-metta, Yaba and Environs)</option>
<option value="Mushin">Mushin</option>
<option value="Ojo">Ojo</option>
<option value="Oshodi-Isolo">Oshodi-Isolo</option>
<option value="Shomolu">Shomolu</option>
<option value="Surulere">Surulere</option>
</select>
    	</div> 
         <br><br><br><div class="form-group">
    		<label for="inputEmail3" class="col-sm-2 control-label">Phone Number</label>
    		<div class="col-sm-10">
      		<input type="text" class="form-control" id="inputEmail3" placeholder="" name="Phone_number" >
    	</div> 
         <br><br><br><div class="form-group">
    		<label for="inputEmail3" class="col-sm-2 control-label">Time</label>
    		<div class="col-sm-10">
      		<input type="time" class="form-control" id="inputEmail3" placeholder="Address" name="time">
    	</div>    
        <br><br><br>
        <div class="form-group">
    		<label for="inputEmail3" class="col-sm-2 control-label">Date</label>
    		<div class="col-sm-10">
      		<input type="date" class="form-control" id="inputEmail3" placeholder="Email" name="date">
    	</div> 
        <br><br><br><div class="form-group">
    		<label for="inputEmail3" class="col-sm-2 control-label">Service Category</label>
    		<div class="col-sm-10">
          <select class="form-control" name="category">
  <option value="Carpenter">Carpenter</option>
  <option value="Masons">Masons</option>
  <option value="Electrician">Electrician</option>
  <option value="Plumber">Plumber</option>
  <option value="Home Moving">Home Moving</option>
  <option value="Fumigation">Fumigation</option>
  <option value="Painting">Painting</option>
</select>
    	</div> 
        <br><br><br>
         <div class="form-group">
    		<label for="inputEmail3" class="col-sm-2 control-label">Task Description</label>
    		<div class="col-sm-10">
                <textarea class="form-control" name="task_description" rows="6" cols="50" ></textarea>
    	</div> 
 			<button type="submit" class="btn btn-default">Submit</button>

    </form></div>