<?php $__env->startSection('content'); ?>
<body class="login">
    <div>
      <a class="hiddenanchor" id="signup"></a>
      <a class="hiddenanchor" id="signin"></a>
<div class="login_wrapper">
        <div class="animate form login_form">
          <section class="login_content">
               <h1>Create Account</h1>
              <div>
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/register')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
 <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" placeholder="Input Your Name here">
                        </div>

                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            
                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" placeholder="Input Your Email here">

                        </div>

                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                              <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                <input id="password" type="password" class="form-control" name="password" placeholder="Input Your Password here">

                              
                        </div>

                        <div class="form-group<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
                               <?php if($errors->has('password_confirmation')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" placeholder="Re-enter Password">

                             
                        </div>
                        

                                <button type="submit" class="btn btn-primary" style="float: right">
                                    <i class="fa fa-btn fa-user"></i> Register
                                </button>
                    </form>
                     <div class="separator">
                <p class="change_link">Already a member ?
                  <a href="<?php echo e(url('/login')); ?>" class="to_register"> Log in </a>
                </p><br>
<div>
                  <h1><i class="fa fa-paw"></i>Kichor.com</h1>
                  <p>©2016 All Rights Reserved. Kichor.com</p>
                </div>
                <div class="clearfix"></div>
                <br />

                <div>
                    
        </div>
      </div>
                    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.reg', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>